<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    const TYPE_SUPERADMIN = 1;
    const TYPE_ADMIN = 2;
    const TYPE_SUBADMIN = 3;
    const TYPE_USER = 4;
    const TYPE_MEMBER = 5;
    
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'first_name', 'last_name', 'email', 'google_id', 'facebook_id', 'linkedin_id',
        'password', 'user_type', 'is_deleted', 'location', 'expyear', 'avail', 'citizen', 'language', 'skills', 'expertise', 'contact', 'referrer'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function UserInterest(){
         return $this->hasMany('App\UserInterest');
    }

    public function Application(){
         return $this->hasMany('App\Application');
    }
}
